

import pygame, sys

from pygame import Vector2

from timer import Timer


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((1200, 720))
        self.x_offset = 0
        
        self.background_sprite = pygame.sprite.GroupSingle()
        self.BG = BackGround((0, 520))
        self.background_sprite.add(self.BG)

        self.minimap_BG_sprite = pygame.sprite.GroupSingle()
        self.minimap_BG = MiniMap((600, 0), self.background_sprite)
        self.minimap_BG_sprite.add(self.minimap_BG)

        self.top_margin_sprite = pygame.sprite.GroupSingle()
        self.top_margin = TopMargin()
        self.top_margin_sprite.add(self.top_margin)

        self.ship_sprite = pygame.sprite.GroupSingle()
        self.ship = Ship((200, 500))
        self.ship_sprite.add(self.ship)

    def draw_screen(self):
        self.screen.fill((0, 0, 0, 0))
        self.background_sprite.draw(self.screen)
        self.minimap_BG_sprite.draw(self.screen)
        self.top_margin_sprite.draw(self.screen)
        self.ship_sprite.draw(self.screen)
        pygame.display.update()

    def run(self):
        self.ticks = pygame.time.get_ticks()
        while True:
            self.dt = (pygame.time.get_ticks() - self.ticks)
            self.ticks = pygame.time.get_ticks()
            self.mouse_pos = self.get_events()
            pygame.display.set_caption(f'{self.BG.acc}')

            self.background_sprite.update(self.dt)
            self.minimap_BG_sprite.update(self.dt)
            self.ship_sprite.update(self.dt)

            self.draw_screen()
            
    def get_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_b:
                    self.BG.reversed = not self.BG.reversed
                    self.ship.reversed = not self.BG.reversed
                # elif event.key == pygame.K_LEFT:
                #     self.BG.reversed = False
        self.BG.get_input()
        self.ship.get_input()


class MiniMap(pygame.sprite.Sprite):
    def __init__(self, pos, background_sprite):
        super().__init__()
        self.image = pygame.Surface((1200, 120))
        self.pos = Vector2(pos)
        self.image = pygame.image.load('minimap_ground.png')
        self.rect = self.image.get_rect(midtop = pos)
        self.background_sprite = background_sprite

    def update(self, dt):
        self.pos.x  = 362 + self.background_sprite.sprite.rect.left / 6.95
        self.rect.left = round(self.pos.x)


class TopMargin(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load('top_margin.png').convert_alpha()
        self.rect = self.image.get_rect(topleft = (0, 0))


class BackGround(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.image.load('alpha_ground.png').convert_alpha()
        self.rect = self.image.get_rect(topleft = pos)
        self.pos = Vector2(pos)
        self.direction = Vector2(0)
        self.movement_speed = .1
        self.acc = 0
        self.vel = Vector2()
        self.reversed = True

    def get_input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_RIGHT]:
            if not self.reversed:
                self.vel.x += .04
            else:
                self.vel.x -= .04
        else:
            if self.vel.x > 0:
                self.vel.x *= .99
            if self.vel.x < 0:
                self.vel.x *= .99
            if self.vel.x > -.005 and self.vel.x < .005:
                self.vel.x = 0

    def update(self, dt):
        print(self.vel.x)
        self.pos.x += self.vel.x
        self.rect.left = round(self.pos.x)
        if self.rect.left < -3240:
            self.pos.x = 0
        elif self.rect.left > 0:
            self.pos.x = -3240


class Ship(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface((50, 10)).convert_alpha()
        self.rect = self.image.get_rect(center = pos)
        self.image.fill((0, 200, 0))
        self.pos = Vector2(pos)
        self.reversed = False
        self.vel = Vector2()
        
    def get_input(self):
        key = pygame.key.get_pressed()
        if key[pygame.K_UP]and self.rect.top > 120:
            self.pos.y -= 3
        elif key[pygame.K_DOWN] and self.rect.bottom < 720:
            self.pos.y += 3
        self.rect.top = round(self.pos.y)

    def update(self,dt):
        if self.reversed:
            if self.pos.x < 1000:
                self.pos.x += 3
                self.rect.centerx = round(self.pos.x)
        else:
            if self.pos.x > 200:
                self.pos.x -= 3
                self.rect.centerx = round(self.pos.x)

        
            
if __name__ == '__main__':
    game = Game()
    game.run()