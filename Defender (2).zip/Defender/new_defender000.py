

import pygame, sys

from pygame import Vector2

from timer import Timer


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((1200, 800))
        
        self.worldOffset = 0
        
        self.background_sprite = pygame.sprite.GroupSingle()
        self.BG = BackGround((0, 550))
        self.background_sprite.add(self.BG)

        self.minimap_BG_sprite = pygame.sprite.GroupSingle()
        self.minimap_BG = MiniMap((362, -5), self.BG)
        self.minimap_BG_sprite.add(self.minimap_BG)

        self.top_margin_sprite = pygame.sprite.GroupSingle()
        self.top_margin = TopMargin()
        self.top_margin_sprite.add(self.top_margin)

        self.ship_sprite = pygame.sprite.GroupSingle()
        self.ship = Ship((200, 500), self.BG)
        self.ship_sprite.add(self.ship)

        self.reversed = False

    def draw_screen(self):
        self.screen.fill((0, 0, 0))
        self.background_sprite.draw(self.screen)
        self.minimap_BG_sprite.draw(self.screen)
        self.top_margin_sprite.draw(self.screen)
        self.ship_sprite.draw(self.screen)

        pygame.display.update()

    def run(self):
        self.ticks = pygame.time.get_ticks()
        while True:
            self.dt = (pygame.time.get_ticks() - self.ticks)
            self.ticks = pygame.time.get_ticks()
            self.mouse_pos = self.get_events()
            pygame.display.set_caption(f'{self.dt}')

            self.minimap_BG_sprite.update(self.dt)
            self.ship_sprite.update(self.dt)

            self.draw_screen()
            
    def get_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_b:
                    self.ship.toggle_reverse()
        self.ship.get_input()


class MiniMap(pygame.sprite.Sprite):
    def __init__(self, pos, background):
        super().__init__()
        self.pos = Vector2(pos)
        self.image = pygame.image.load('minimap_ground.png').convert_alpha()
        self.rect = self.image.get_rect(topleft = pos)
        self.background = background

    def update(self, dt):
        self.rect.left = round(self.background.rect.left / 13.021) + 362


class TopMargin(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load('top_margin.png').convert_alpha()
        self.rect = self.image.get_rect(topleft = (0, 0))


class BackGround(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.image.load('alpha_ground.png').convert_alpha()
        self.rect = self.image.get_rect(topleft = pos)


class Ship(pygame.sprite.Sprite):
    def __init__(self, pos, background):
        super().__init__()
        self.image = pygame.image.load('ship.png').convert_alpha()
        self.rect = self.image.get_rect(center = pos)
        self.pos = Vector2(pos)
        self.reversed = False
        self.vel = Vector2()
        self.worldOffset = 0
        self.background = background
        
    def get_input(self):
        key = pygame.key.get_pressed()
        if key[pygame.K_UP]and self.rect.top > 120:
            self.pos.y -= 3
        elif key[pygame.K_DOWN] and self.rect.bottom < 800:
            self.pos.y += 3
        self.rect.y = round(self.pos.y)
        if key[pygame.K_RIGHT]:
            if not self.reversed:
                self.vel.x -= .08
            else:
                self.vel.x += .08
        else:
            if self.vel.x > .08 or self.vel.x < -.08:
                self.vel.x *= .99
            else:
                self.vel.x = 0
                
        self.worldOffset += self.vel.x
        if self.worldOffset < -6198:
            self.worldOffset += 6198
        if self.worldOffset > 0:
            self.worldOffset -= 6198
        
    def toggle_reverse(self):
        self.image = pygame.transform.flip(self.image, True, False)
        self.reversed = not self.reversed

    def update(self,dt):
        self.background.rect.left = round(self.worldOffset)
        if self.reversed:
            if self.pos.x < 1000:
                self.pos.x += 3
        else:
            if self.pos.x > 200:
                self.pos.x -= 3
        self.rect.centerx = round(self.pos.x)


if __name__ == '__main__':
    game = Game()
    game.run()